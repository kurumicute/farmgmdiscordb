"""介紹網站（公開）：Bot 功能介紹、邀請連結與彙總統計。預設 Port 24444。

- 只提供彙總數字（玩家數、農場數、伺服器數、今日操作數等），不輸出任何玩家名稱、ID 或個別資料。
- 統計查詢在唯讀交易中執行，結果快取 STATS_CACHE_SECONDS 秒，訪客再多也不會增加資料庫負擔。
- 沒有任何寫入端點；頁面為靜態檔，前端只用 textContent 填入資料。
"""

import logging
import threading
import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker

from app.db.models import Farm, FarmPlot, GameTransaction, Group, Player

logger = logging.getLogger(__name__)
STATIC_DIR = Path(__file__).parent / "static"
STATS_CACHE_SECONDS = 30
# 邀請 Bot 需要的權限：檢視頻道、傳送訊息、嵌入連結、附加檔案、讀取訊息紀錄、連接語音、說話
INVITE_PERMISSIONS = 1024 + 2048 + 16384 + 32768 + 65536 + 1048576 + 2097152

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": (
        "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
    ),
}


def invite_url(application_id: int | None) -> str | None:
    if not application_id:
        return None
    return (
        f"https://discord.com/oauth2/authorize?client_id={application_id}"
        f"&scope=bot+applications.commands&permissions={INVITE_PERMISSIONS}"
    )


class StatsCache:
    def __init__(self, factory: sessionmaker[Session] | None, ttl: float = STATS_CACHE_SECONDS) -> None:
        self.factory = factory
        self.ttl = ttl
        self._value: dict | None = None
        self._at = 0.0
        self._lock = threading.Lock()

    def get(self) -> dict | None:
        with self._lock:
            if self._value is not None and time.monotonic() - self._at < self.ttl:
                return self._value
            if self.factory is None:
                return None
            with self.factory() as session:
                session.execute(text("SET TRANSACTION READ ONLY"))
                since = session.scalar(text("SELECT date_trunc('day', now() AT TIME ZONE 'Asia/Taipei') "
                                            "AT TIME ZONE 'Asia/Taipei'"))
                self._value = {
                    "players": session.scalar(select(func.count()).select_from(Player)) or 0,
                    "farms": session.scalar(select(func.count()).select_from(Farm)) or 0,
                    "servers": session.scalar(
                        select(func.count()).select_from(Group).where(Group.discord_guild_id.is_not(None))
                    ) or 0,
                    "growing": session.scalar(
                        select(func.count()).select_from(FarmPlot).where(FarmPlot.crop_type_id.is_not(None))
                    ) or 0,
                    "actions_today": session.scalar(
                        select(func.count()).select_from(GameTransaction).where(GameTransaction.created_at >= since)
                    ) or 0,
                    "last_activity": session.scalar(select(func.max(GameTransaction.created_at))),
                }
            self._at = time.monotonic()
            return self._value


def create_site_app(
    session_factory: sessionmaker[Session] | None = None,
    *,
    site_name: str = "星月農場",
    application_id: int | None = None,
    support_url: str | None = None,
    music_enabled: bool = True,
    music_application_id: int | None = None,
) -> FastAPI:
    app = FastAPI(title=site_name, docs_url=None, redoc_url=None, openapi_url=None)
    stats = StatsCache(session_factory)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        for key, value in SECURITY_HEADERS.items():
            response.headers.setdefault(key, value)
        # 網站更新後訪客立即看到新版：瀏覽器可快取，但每次先向伺服器確認（ETag）
        response.headers.setdefault("Cache-Control", "no-cache")
        return response

    @app.get("/api/info")
    async def info() -> dict:
        return {
            "name": site_name,
            "invite_url": invite_url(application_id),
            # 音樂改用獨立 Bot 時，另外提供音樂 Bot 的邀請連結
            "music_invite_url": invite_url(music_application_id),
            "support_url": support_url,
            "music_enabled": music_enabled,
        }

    @app.get("/api/stats")
    async def get_stats():
        try:
            value = await run_in_threadpool(stats.get)
        except SQLAlchemyError as exc:
            logger.warning("介紹網站統計查詢失敗：%s", type(exc).__name__)
            return JSONResponse(status_code=503, content={"detail": "統計資料暫時無法取得"})
        if value is None:
            return JSONResponse(status_code=503, content={"detail": "統計資料暫時無法取得"})
        return {**value, "cached_seconds": STATS_CACHE_SECONDS}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon() -> FileResponse:
        return FileResponse(STATIC_DIR / "favicon.svg", media_type="image/svg+xml")

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    return app
