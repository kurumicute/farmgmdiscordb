// 介紹網站：填入邀請連結與即時統計。一律用 textContent，不使用 innerHTML。
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const num = new Intl.NumberFormat("zh-TW");
  const time = new Intl.DateTimeFormat("zh-TW", { dateStyle: "short", timeStyle: "short", timeZone: "Asia/Taipei" });

  function setText(id, value) {
    const node = $(id);
    if (node) node.textContent = value;
  }

  async function loadInfo() {
    try {
      const res = await fetch("/api/info", { headers: { Accept: "application/json" } });
      if (!res.ok) return;
      const info = await res.json();
      setText("site-name", info.name);
      setText("footer-name", info.name);
      if (info.invite_url) {
        for (const id of ["invite-btn", "invite-link"]) {
          const a = $(id);
          a.href = info.invite_url;
          a.target = "_blank";
          a.rel = "noopener";
        }
      }
      if (info.music_invite_url) {
        const a = $("music-invite-btn");
        a.href = info.music_invite_url;
        a.target = "_blank";
        a.rel = "noopener";
        a.hidden = false;
      }
      if (info.support_url) {
        for (const id of ["support-btn", "support-link"]) {
          const a = $(id);
          a.href = info.support_url;
          a.target = "_blank";
          a.rel = "noopener";
          a.hidden = false;
        }
      } else {
        $("support-link").parentElement.hidden = true;
      }
    } catch (err) {
      // 網路錯誤時保留預設連結
    }
  }

  async function loadStats() {
    try {
      const res = await fetch("/api/stats", { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(String(res.status));
      const s = await res.json();
      for (const [id, key] of [["stat-players", "players"], ["s-players", "players"], ["stat-servers", "servers"],
        ["s-servers", "servers"], ["stat-growing", "growing"], ["s-growing", "growing"], ["s-farms", "farms"],
        ["s-today", "actions_today"]]) {
        setText(id, num.format(s[key]));
      }
      setText("s-last", s.last_activity ? time.format(new Date(s.last_activity)) : "—");
      setText("status-note", `統計每 ${s.cached_seconds} 秒更新一次。最後更新：${time.format(new Date())}`);
    } catch (err) {
      setText("status-note", "統計資料暫時無法取得，請稍後再試。");
    }
  }

  function petals() {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const box = $("petals");
    for (let i = 0; i < 18; i += 1) {
      const p = document.createElement("span");
      p.className = "petal";
      p.style.left = `${Math.random() * 100}vw`;
      p.style.animationDuration = `${9 + Math.random() * 10}s`;
      p.style.animationDelay = `${-Math.random() * 15}s`;
      const size = 0.6 + Math.random() * 0.8;
      p.style.width = `${12 * size}px`;
      p.style.height = `${10 * size}px`;
      box.appendChild(p);
    }
  }

  petals();
  loadInfo();
  loadStats();
  setInterval(loadStats, 30000);
})();
