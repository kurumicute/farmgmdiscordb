# ruff: noqa: E501  （報表輸出字串較長）
"""音樂壓力測試（不需要 Discord Token，也不會連到語音伺服器）。

1. 音訊管線容量：N 條串流同時「ffmpeg 解碼 → 音量 → Opus 編碼」，以即時速度（每 20 ms 一個封包）執行，
   與 discord.py 實際播放時相同；量測封包延遲、CPU 與記憶體，估計同時能播幾個伺服器。
2. 佇列／事件迴圈：數百個伺服器同時點歌、切歌（歌曲解析以延遲模擬網路），量測事件迴圈延遲與切歌等待時間。
3. （選用 --network）實際用 yt-dlp 搜尋 YouTube 少量歌曲，量測解析時間。只做少量查詢，避免被 YouTube 限流。

用法：.venv/Scripts/python.exe scripts/music_stresstest.py [--streams 10,25,50,100] [--seconds 15] [--network]
"""

import argparse
import asyncio
import os
import shutil
import statistics
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from types import SimpleNamespace

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import discord  # noqa: E402
import psutil  # noqa: E402

from app.music import player as music  # noqa: E402

FRAME = 0.02  # discord.py 每 20 ms 送出一個語音封包


def make_test_audio() -> str:
    """用 ffmpeg 產生 30 秒的立體聲測試音檔（只產生一次）。"""
    path = os.path.join(tempfile.gettempdir(), "farmgm_music_test.mp3")
    if not os.path.isfile(path):
        ffmpeg = shutil.which("ffmpeg") or "ffmpeg"
        subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=30",
                        "-ac", "2", "-ar", "48000", "-b:a", "128k", path], check=True)
    return path


class AudioLoad:
    """N 條即時播放的音訊串流（每條一個執行緒＋一個 ffmpeg 子程序），與 discord.py 的 AudioPlayer 相同節奏。"""

    def __init__(self, path: str, streams: int) -> None:
        self.path, self.streams = path, streams
        self.stop_event = threading.Event()
        self.threads: list[threading.Thread] = []
        self.frames = 0
        self.late = 0
        self.max_late = 0.0
        self.lock = threading.Lock()
        self.proc = psutil.Process()
        self.started = 0.0

    def _run(self) -> None:
        encoder = discord.opus.Encoder()
        source = discord.PCMVolumeTransformer(
            discord.FFmpegPCMAudio(self.path, before_options="-stream_loop -1 -nostdin", options="-vn"), 0.5
        )
        start, loops = time.perf_counter(), 0
        try:
            while not self.stop_event.is_set():
                data = source.read()
                if not data:
                    break
                encoder.encode(data, encoder.SAMPLES_PER_FRAME)
                loops += 1
                delay = start + FRAME * loops - time.perf_counter()
                with self.lock:
                    self.frames += 1
                    if delay < -0.01:  # 比預定時間晚超過 10 ms，聽起來可能卡頓
                        self.late += 1
                        self.max_late = max(self.max_late, -delay * 1000)
                if delay > 0:
                    time.sleep(delay)
        finally:
            source.cleanup()

    def start(self) -> None:
        discord.opus._load_default()
        self.proc.cpu_percent(None)
        self.started = time.perf_counter()
        for _ in range(self.streams):
            t = threading.Thread(target=self._run, daemon=True)
            t.start()
            self.threads.append(t)

    def sample(self) -> tuple[float, float, float]:
        """(Python 程序 CPU%, ffmpeg 子程序 CPU% 合計, 記憶體 MB)；CPU% 以單核 100% 計。"""
        children = self.proc.children(recursive=True)
        for c in children:
            try:
                c.cpu_percent(None)
            except psutil.Error:
                pass
        time.sleep(1.0)
        own = self.proc.cpu_percent(None)
        child = 0.0
        mem = self.proc.memory_info().rss
        for c in children:
            try:
                child += c.cpu_percent(None)
                mem += c.memory_info().rss
            except psutil.Error:
                pass
        return own, child, mem / 2**20

    def stop(self) -> str:
        self.stop_event.set()
        for t in self.threads:
            t.join(timeout=5)
        secs = time.perf_counter() - self.started
        expected = self.streams * secs / FRAME
        return (f"{self.streams} 條串流 {secs:.0f} 秒：封包 {self.frames}（應有約 {expected:.0f}），"
                f"延遲超過 10 ms 的封包 {self.late}（{self.late / max(1, self.frames):.2%}），最大延遲 {self.max_late:.0f} ms")


def audio_capacity(counts: list[int], seconds: int) -> None:
    print("\n--- 1. 音訊管線容量（ffmpeg 解碼 + 音量 + Opus 編碼，即時速度）---")
    print(f"CPU：{os.cpu_count()} 個邏輯核心（CPU% 以單核 100% 計，整台電腦上限 {os.cpu_count() * 100}%）")
    path = make_test_audio()
    for n in counts:
        load = AudioLoad(path, n)
        load.start()
        time.sleep(2)  # 等 ffmpeg 全部啟動
        samples = [load.sample() for _ in range(max(1, seconds - 2))]
        report = load.stop()
        own = statistics.mean(s[0] for s in samples)
        child = statistics.mean(s[1] for s in samples)
        mem = max(s[2] for s in samples)
        print(f"[{n:>3} 個伺服器同時播放] Bot 程序 CPU {own:6.1f}%（每條 {own / n:.2f}%）、ffmpeg 合計 {child:6.1f}%、"
              f"記憶體 {mem:,.0f} MB（含 ffmpeg）\n    {report}")


async def queue_stress(guild_count: int, songs_each: int, extract_delay: float) -> None:
    print(f"\n--- 2. 佇列與事件迴圈：{guild_count} 個伺服器各點 {songs_each} 首、快速切歌（模擬解析 {extract_delay * 1000:.0f} ms）---")
    loop = asyncio.get_running_loop()
    music.configure(music.MusicConfig(settings_file=os.path.join(tempfile.gettempdir(), "farmgm_music_stress.json")))
    music.states.clear()
    switch_waits: list[float] = []
    ended = {}

    class Voice:
        def __init__(self, gid):
            self.gid, self.playing, self.after, self.channel = gid, False, None, SimpleNamespace(members=[])

        def is_connected(self):
            return True

        def is_playing(self):
            return self.playing

        def is_paused(self):
            return False

        def play(self, source, after):
            if self.gid in ended:
                switch_waits.append((time.perf_counter() - ended.pop(self.gid)) * 1000)
            self.playing, self.after = True, after
            loop.call_later(0.02, self.finish)  # 每首「播」20 ms 就結束，製造大量切歌

        def finish(self):
            self.playing = False
            ended[self.gid] = time.perf_counter()
            self.after(None)

        def stop(self):
            pass

    guilds = {g: SimpleNamespace(id=g, name=f"g{g}", voice_client=Voice(g), icon=None) for g in range(1, guild_count + 1)}
    music.bot = SimpleNamespace(loop=loop, get_guild=guilds.get, user=SimpleNamespace(id=1))

    def fake_stream(song):
        time.sleep(extract_delay)  # yt-dlp 解析（網路）時間；在執行緒中執行，不阻塞事件迴圈
        return {"url": song.url, "headers": {}}

    music.get_stream_info = fake_stream
    music.make_source = lambda stream, volume: stream["url"]
    for g in guilds:
        st = music.get_state(g)
        st.queue.extend(music.Song(title=f"{g}-{i}", url=f"https://www.youtube.com/watch?v={g}{i}") for i in range(songs_each))

    lags = []
    done = asyncio.Event()

    async def heartbeat():
        while not done.is_set():
            t = time.perf_counter()
            await asyncio.sleep(0.05)
            lags.append((time.perf_counter() - t - 0.05) * 1000)

    hb = asyncio.create_task(heartbeat())
    t0 = time.perf_counter()
    await asyncio.gather(*(music.play_next(g) for g in guilds.values()))
    while any(music.get_state(g).queue or music.get_state(g).current for g in guilds):
        await asyncio.sleep(0.1)
        if time.perf_counter() - t0 > 600:
            break
    elapsed = time.perf_counter() - t0
    done.set()
    await hb
    for g in guilds:
        music.get_state(g).cancel_tasks()
    total = guild_count * songs_each
    switch_waits.sort()
    print(f"{total} 首歌 {elapsed:.1f} 秒播完；切歌等待（上一首結束到下一首開始）："
          f"P50 {switch_waits[len(switch_waits) // 2]:.0f} ms、P95 {switch_waits[int(len(switch_waits) * .95)]:.0f} ms、"
          f"最大 {switch_waits[-1]:.0f} ms")
    lags.sort()
    print(f"事件迴圈延遲：P95 {lags[int(len(lags) * .95)]:.1f} ms、最大 {lags[-1]:.1f} ms")
    print(f"（解析在音樂專用執行緒池進行，最多 {music._extract_pool._max_workers} 條同時解析。這裡每首只播 20 ms，"
          f"來不及預先載入下一首，是最壞情況；實際歌曲有數分鐘，下一首會在切歌前就解析完成）")


async def network_check(queries: list[str]) -> None:
    print(f"\n--- 3. 實際 yt-dlp 解析（{len(queries)} 首，同時進行）---")
    music.configure(music.MusicConfig())

    async def one(q):
        t = time.perf_counter()
        _name, songs = await asyncio.to_thread(music.get_songs, q, None)
        t_search = time.perf_counter() - t
        stream = await asyncio.to_thread(music.get_stream_info, songs[0]) if songs else None
        return q, t_search, time.perf_counter() - t, bool(stream)

    for q, search, total, ok in await asyncio.gather(*(one(q) for q in queries)):
        print(f"  {q:<28} 搜尋 {search:5.1f} 秒、取得串流共 {total:5.1f} 秒、{'成功' if ok else '失敗'}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--streams", default="10,25,50,100")
    parser.add_argument("--seconds", type=int, default=15)
    parser.add_argument("--guilds", type=int, default=300)
    parser.add_argument("--network", action="store_true")
    args = parser.parse_args()
    print("===== 音樂壓力測試 =====")
    audio_capacity([int(x) for x in args.streams.split(",")], args.seconds)
    asyncio.run(queue_stress(args.guilds, 10, 0.3))
    if args.network:
        asyncio.run(network_check(["lofi hip hop", "周杰倫 晴天", "YOASOBI アイドル", "never gonna give you up", "Bach cello suite"]))


if __name__ == "__main__":
    main()
