"""音樂模組（原 YTDiscordBot 移植）：與農場合併後的指令註冊，以及播放佇列邏輯（假的語音連線，不連網）。"""

import asyncio
from types import SimpleNamespace

import pytest

from app.config import Settings
from app.discord_bot.bot import FarmBot, bot_intents
from app.discord_bot.runner import ServiceRunner
from app.music import player as music

MUSIC_COMMANDS = {"join", "play", "bilibili", "nowplaying", "queue", "skip", "pause", "resume", "stop", "loop",
                  "shuffle", "remove", "clear", "leave", "volume", "prefix", "music"}


def settings(**kw):
    return Settings(_env_file=None, database_url="postgresql+psycopg://x@localhost/x_test", **kw)


@pytest.fixture
def runner():
    r = ServiceRunner(1)
    yield r
    r.shutdown()


def test_merged_bot_registers_farm_and_music(runner, tmp_path):
    bot = FarmBot(settings(music_volume=0.3), None, runner)
    names = [c.name for c in bot.tree.get_commands()]
    assert len(names) == len(set(names))
    assert {"farm", "help"} | MUSIC_COMMANDS == set(names)
    for command in bot.tree.get_commands():
        command.to_dict(bot.tree)  # Discord 指令格式驗證
    assert {c.name for c in bot.commands} == MUSIC_COMMANDS  # 前綴版本
    assert music.default_volume == 0.3 and "cookiefile" not in music.BASE_YDL_OPTIONS


def test_intents_and_music_toggle(runner):
    plain = bot_intents(settings())
    assert plain.guilds and plain.voice_states and not plain.message_content
    prefixed = bot_intents(settings(music_prefix_commands=True))
    assert prefixed.message_content and prefixed.guild_messages
    no_music = FarmBot(settings(music_enabled=False), None, runner)
    assert {c.name for c in no_music.tree.get_commands()} == {"farm", "help"}
    assert not bot_intents(settings(music_enabled=False)).voice_states


def test_advanced_farm_commands_do_not_collide(runner):
    bot = FarmBot(settings(discord_advanced_commands=True), None, runner)
    names = [c.name for c in bot.tree.get_commands()]
    assert len(names) == len(set(names)) and "clear-withered" in names and "clear" in names


def test_cookies_optional(tmp_path):
    music.configure(music.MusicConfig(cookies_path=str(tmp_path / "missing.txt"),
                                      settings_file=str(tmp_path / "s.json")))
    assert "cookiefile" not in music.BASE_YDL_OPTIONS
    cookies = tmp_path / "cookies.txt"
    cookies.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
    music.configure(music.MusicConfig(cookies_path=str(cookies), settings_file=str(tmp_path / "s.json")))
    assert music.STREAM_YDL_OPTIONS["cookiefile"] == str(cookies)
    music.configure(music.MusicConfig(settings_file=str(tmp_path / "s.json")))
    assert "cookiefile" not in music.STREAM_YDL_OPTIONS


# ---------- 播放佇列（假的語音連線） ----------


class FakeVoice:
    def __init__(self):
        self.playing = self.paused = False
        self.after = None
        self.source = None
        self.played = []
        self.channel = SimpleNamespace(members=[])

    def is_connected(self):
        return True

    def is_playing(self):
        return self.playing

    def is_paused(self):
        return self.paused

    def play(self, source, after):
        self.playing, self.after, self.source = True, after, source
        self.played.append(source)

    def stop(self):
        if self.playing or self.paused:
            self.playing = self.paused = False
            self.after(None)


def install_fakes(monkeypatch, tmp_path, guild_ids):
    music.configure(music.MusicConfig(settings_file=str(tmp_path / "s.json")))
    guilds = {gid: SimpleNamespace(id=gid, name=f"g{gid}", voice_client=FakeVoice(), icon=None) for gid in guild_ids}
    loop = asyncio.get_running_loop()
    monkeypatch.setattr(music, "bot", SimpleNamespace(loop=loop, get_guild=guilds.get, user=SimpleNamespace(id=1)))
    monkeypatch.setattr(music, "get_stream_info", lambda song: {"url": song.url, "headers": {}})
    monkeypatch.setattr(music, "make_source", lambda stream, volume: stream["url"])
    music.states.clear()
    return guilds


def song(n):
    return music.Song(title=f"song{n}", url=f"https://www.youtube.com/watch?v={n}")


async def settle():
    for _ in range(20):
        await asyncio.sleep(0)


def test_queue_play_skip_loop_stop(monkeypatch, tmp_path):
    async def scenario():
        guild = install_fakes(monkeypatch, tmp_path, [10])[10]
        vc = guild.voice_client
        state = music.get_state(10)
        state.queue.extend(song(i) for i in range(3))
        await music.play_next(guild)
        assert state.current.title == "song0" and vc.played == [song(0).url]
        vc.stop()  # 歌曲結束 → 自動播下一首
        await settle()
        assert state.current.title == "song1"
        state.loop = "song"
        vc.stop()  # 單曲循環：同一首再播一次
        await settle()
        assert state.current.title == "song1"
        state.skip_requested = True
        vc.stop()  # 跳過：即使單曲循環也前進
        await settle()
        assert state.current.title == "song2"
        music.stop_playback(guild)
        await settle()
        assert state.current is None and not state.queue
        state.cancel_tasks()

    asyncio.run(scenario())


def test_many_guilds_are_independent(monkeypatch, tmp_path):
    async def scenario():
        guilds = install_fakes(monkeypatch, tmp_path, range(1, 51))
        for gid in guilds:
            music.get_state(gid).queue.extend(song(gid * 100 + i) for i in range(2))
        await asyncio.gather(*(music.play_next(g) for g in guilds.values()))
        assert all(music.get_state(gid).current.title == f"song{gid * 100}" for gid in guilds)
        for g in guilds.values():
            g.voice_client.stop()
        await settle()
        assert all(music.get_state(gid).current.title == f"song{gid * 100 + 1}" for gid in guilds)
        for gid in guilds:
            music.get_state(gid).cancel_tasks()

    asyncio.run(scenario())


def test_volume_setting_persists(monkeypatch, tmp_path):
    async def scenario():
        guild = install_fakes(monkeypatch, tmp_path, [7])[7]
        music.change_volume(guild, 0.8)
        music.configure(music.MusicConfig(settings_file=str(tmp_path / "s.json")))  # 重新讀檔（模擬重啟）
        music.states.clear()
        assert music.get_state(7).volume == 0.8

    asyncio.run(scenario())


def test_stream_cache_avoids_repeat_extraction(monkeypatch):
    calls = []

    def fake_extract(opts, target, retries=2):
        calls.append(target)
        return {"url": f"https://stream/{target}", "http_headers": {}, "title": "歌名", "duration": 120}

    monkeypatch.setattr(music, "extract", fake_extract)
    music._stream_cache.clear()
    first = music.Song(title="x", url="https://www.youtube.com/watch?v=abc", needs_info=True)
    assert music.get_stream_info(first)["url"].endswith("watch?v=abc") and first.title == "歌名"
    again = music.Song(title="x", url="https://www.youtube.com/watch?v=abc", needs_info=True)
    assert music.get_stream_info(again)["url"].endswith("watch?v=abc") and again.title == "歌名"
    assert len(calls) == 1  # 第二次直接用快取，不再啟動解析
    monkeypatch.setattr(music.time, "monotonic", lambda: 10**9)  # 快取過期後重新解析
    music.get_stream_info(again)
    assert len(calls) == 2
    music._stream_cache.clear()


def test_separate_music_process_mode(runner):
    from pydantic import SecretStr

    from app.music.__main__ import MusicBot, music_intents

    split = settings(music_bot_token=SecretStr("x" * 10), music_application_id=123)
    farm_only = FarmBot(split, None, runner)
    assert {c.name for c in farm_only.tree.get_commands()} == {"farm", "help"}  # 農場程序不再載入音樂
    assert not bot_intents(split).voice_states
    music_bot = MusicBot(split)
    names = {c.name for c in music_bot.tree.get_commands()}
    assert names == MUSIC_COMMANDS
    for command in music_bot.tree.get_commands():
        command.to_dict(music_bot.tree)
    assert music_intents(split).voice_states and not music_intents(split).message_content
